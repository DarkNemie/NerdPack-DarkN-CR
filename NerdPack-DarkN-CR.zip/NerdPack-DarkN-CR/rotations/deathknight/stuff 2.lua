--[[
buffs debuffs etc.

	194594 lock n load
	223138 Marking target
	187131 Vulnerable on target
	185365 marked target 
	
	
	
	
	
	
]]--