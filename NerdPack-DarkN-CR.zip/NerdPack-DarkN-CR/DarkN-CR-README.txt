<<<<<<< HEAD
DarkNemie's READ ME file

-- This is a basic list of combat rotations that have been updated to WoW 7.0.x

======================================================================================
Hunter - Marksman 			- Currently in progress
--------------------------------------------------------------------------------------
Basic Rotations fir all MM builds functional, this will be the best 
it will get till more info on gear, stats, skills become available.

Optimised Rotation using talent build : 1, 1, 2, 3, 1, 2, 1					- Complete

Skill usage for all other builds, %50 complete but commented out
Minor clean up of unused functions and skills in the old MM.lua
optimise for MHFC raiding /W 4pcT18 set,									-Complete

In-progress :

add function checks for Aimed Shot while moving - to stop broken casts/trying to
cast while moving for non 4pcT18.

======================================================================================
Hunter - Beast Master 		- On Hold updated by another player
--------------------------------------------------------------------------------------


======================================================================================
Hunter - Survival 			- Will start after MM rotation is optimized for pre-patch
--------------------------------------------------------------------------------------
=======
DarkNemie's READ ME file

-- This is a basic list of combat rotations that have been updated to WoW 7.0.x

======================================================================================
Hunter - Marksman 			- Currently in progress
--------------------------------------------------------------------------------------
Basic Rotations fir all MM builds functional, this will be the best 
it will get till more info on gear, stats, skills become available.

Optimised Rotation using talent build : 1, 1, 2, 3, 1, 2, 1					- Complete

Skill usage for all other builds, %50 complete but commented out
Minor clean up of unused functions and skills in the old MM.lua
optimise for MHFC raiding /W 4pcT18 set,									-Complete

In-progress :

add function checks for Aimed Shot while moving - to stop broken casts/trying to
cast while moving for non 4pcT18.

======================================================================================
Hunter - Beast Master 		- On Hold updated by another player
--------------------------------------------------------------------------------------


======================================================================================
Hunter - Survival 			- Will start after MM rotation is optimized for pre-patch
--------------------------------------------------------------------------------------
>>>>>>> a001e6c9e29f1c87d853645f3410e6c3498d7929
